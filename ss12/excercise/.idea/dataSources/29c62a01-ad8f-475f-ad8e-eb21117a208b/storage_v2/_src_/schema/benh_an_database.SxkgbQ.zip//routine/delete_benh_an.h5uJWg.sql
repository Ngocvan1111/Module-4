create
    definer = root@localhost procedure delete_benh_an(IN id_in varchar(45))
begin
SET FOREIGN_KEY_CHECKS=0;
delete from benh_an where ma_benh_an = id_in;
end;


create
    definer = root@localhost procedure find_all()
begin
select ba.*, bn.ten_benh_nhan as ten_benh_nhan from benh_an ba join benh_nhan bn on ba.ma_benh_nhan = bn.ma_benh_nhan;
end;

